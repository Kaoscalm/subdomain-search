# subdomain-search
Search availability subdomain name script
